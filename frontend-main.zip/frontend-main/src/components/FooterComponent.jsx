import React, { Component } from "react";

export default class FooterComponent extends Component {
  render() {
    return (
      <div>
        <footer className="footer">
          <span className="text-muted">
            All Rights Reserved 2020 @DursunEryilmaz
          </span>
        </footer>
      </div>
    );
  }
}
